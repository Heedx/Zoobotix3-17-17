package org.usfirst.frc.team6002.robot;

import edu.wpi.cscore.AxisCamera;
import edu.wpi.cscore.CvSink;
import edu.wpi.cscore.CvSource;
import edu.wpi.first.wpilibj.CameraServer;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

import org.usfirst.frc.team6002.robot.subsystems.Drive;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.imgproc.Imgproc;
import org.usfirst.frc.team6002.robot.subsystems.Climber;
import org.usfirst.frc.team6002.robot.subsystems.Rollers;
import org.usfirst.frc.team6002.robot.subsystems.Shooter;
import org.usfirst.frc.team6002.robot.subsystems.GearArm;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
public class Robot extends IterativeRobot {
	private static OI oi;
	private static Drive chassis;
	private static Climber climber;
	private static Rollers roller;
	private static Shooter shooter;
	private static GearArm geararm;

	private static Timer timer;

	private double startShootTime;
	
	//Variables for autonomous
	private boolean getStartTimeInAuto;
	private double startTimeInAuto;
	private int stepInAuto;

	private int autoSelection;

	//Thread visionThread;
	
	Command autonomousCommand;
	SendableChooser<Command> chooser = new SendableChooser<>();
	
	/**
	 * This function is run when the robot is first started up and should be
	 * used for any initialization code.
	 */
	@Override
	public void robotInit() {
		oi = new OI();
		chassis = new Drive();
		climber = new Climber();
		roller = new Rollers();
		shooter = new Shooter();
		geararm = new GearArm();

		timer = new Timer();
		timer.start();

		// chooser.addObject("My Auto", new MyAutoCommand());
		SmartDashboard.putData("Auto mode", chooser);
	
		startShootTime = 0;
		
		autoSelection = 0;

		getStartTimeInAuto = true;
		startTimeInAuto = 0;
		stepInAuto = 0;

		chassis.setLowGear();
		
		// Get the Axis camera from CameraServer
		AxisCamera camera = CameraServer.getInstance().addAxisCamera("axis-camera.local");
		// Set the resolution
		//camera.setResolution(640, 480);
			
		/*
		visionThread = new Thread(() -> {
			

			
			// Get a CvSink. This will capture Mats from the camera
			CvSink cvSink = CameraServer.getInstance().getVideo();
			// Setup a CvSource. This will send images back to the Dashboard
			CvSource outputStream = CameraServer.getInstance().putVideo("Rectangle", 640, 480);

			// Mats are very memory expensive. Lets reuse this Mat.
			Mat mat = new Mat();

			// This cannot be 'true'. The program will never exit if it is. This
			// lets the robot stop this thread when restarting robot code or
			// deploying.
			while (!Thread.interrupted()) {
				// Tell the CvSink to grab a frame from the camera and put it
				// in the source mat.  If there is an error notify the output.
				if (cvSink.grabFrame(mat) == 0) {
					// Send the output the error.
					outputStream.notifyError(cvSink.getError());
					// skip the rest of the current iteration
					continue;
				}
				// Put a rectangle on the image
				Imgproc.rectangle(mat, new Point(100, 100), new Point(400, 400),
						new Scalar(255, 255, 255), 5);
				// Give the output stream a new image to display
				outputStream.putFrame(mat);
			}
		});

		visionThread.setDaemon(true);
		visionThread.start();
		*/
   	}

	/**
	 * This function is called once each time the robot enters Disabled mode.
	 * You can use it to reset any subsystem information you want to clear when
	 * the robot is disabled.
	 */
	@Override
	public void disabledInit() {
		// chassis.setTalonsToVoltageControl();
		// chassis.drive(0, 0);
		// shooter.disableShooterPID();
	}

	@Override
	public void disabledPeriodic() {
		Scheduler.getInstance().run();
//		System.out.println(chassis.convertTicksToInches(chassis.getDrivePIDInput()));
	}

	/**
	 * This autonomous (along with the chooser code above) shows how to select
	 * between different autonomous modes using the dashboard. The sendable
	 * chooser code works with the Java SmartDashboard. If you prefer the
	 * LabVIEW Dashboard, remove all of the chooser code and uncomment the
	 * getString code to get the auto name from the text box below the Gyro
	 *
	 * You can add additional auto modes by adding additional commands to the
	 * chooser code above (like the commented example) or additional comparisons
	 * to the switch structure below with additional strings & commands.
	 */
	@Override
	public void autonomousInit() {
		autonomousCommand = chooser.getSelected();

		/*
		 * String autoSelected = SmartDashboard.getString("Auto Selector",
		 * "Default"); switch(autoSelected) { case "My Auto": autonomousCommand
		 * = new MyAutoCommand(); break; case "Default Auto": default:
		 * autonomousCommand = new ExampleCommand(); break; }
		 */

		//z schedule the autonomous command (example)
		// if (autonomousCommand != null)
		// 	autonomousCommand.start();

		//Get input from the dashboard
		boolean button1 = SmartDashboard.getBoolean("DB/Button 1", false);
		boolean button2 = SmartDashboard.getBoolean("DB/Button 2", false);
		boolean button3 = SmartDashboard.getBoolean("DB/Button 3", false);

		//"Zero" variables in auto
		//These variables help with timing actions in auto
		getStartTimeInAuto = true;
		startTimeInAuto = 0;
		stepInAuto = 0; //This variable is used to know what step of the autonomous sequence the robot is in

		//During the competition, we couldn't read values from the labview dashboard
		//We had the same problem last year. Look into the Java Dashboard
		
		//Do nothing
//		if(button1){
//			chassis.setTalonsToVoltageControl();
//			chassis.enableTalonsControl();
//			chassis.drive(0, 0);
//			autoSelection = 1;
//		}
//		//2 - Drive straight and drop off gyro, 3 - just drive straight
//		else if(button2 || button3){
//			chassis.resetTalonEncoders();
//			chassis.setTalonsToSpeedControl();
//			chassis.enableTalonsPIDLoop();
//
//			if(button2){
//				chassis.setDrivePIDSetpoint(chassis.convertInchesToTicks(80));
//				autoSelection = 2;	
//			}
//			else{
//				chassis.setDrivePIDSetpoint(chassis.convertInchesToTicks(130));
//				autoSelection = 3;
//			}
//			chassis.resetDrivePID();
//	        chassis.enableDrivePID();
//
//	        chassis.setTurnPIDSetpoint(chassis.getGyroAngle());
//			chassis.resetTurnPID();
//	        chassis.enableTurnPID();
//		}
//		else{
//			autoSelection = 1;
//		}
		
		//When you get a dashboard working, use this variable to change autonomous modes
        //2 - middle gear
        //3 - just drive straight(150in)
		//4 - redside gear
		autoSelection = 2;
		
		//These functions help setup the robot to drive in autonomous
		chassis.resetTalonEncoders();
		chassis.setTalonsToSpeedControl(); //Talon set to use velocity PID loop
		chassis.enableTalonsPIDLoop();
		
		//Different distances for different modes
		if(autoSelection == 2){
			chassis.setDrivePIDSetpoint(chassis.convertInchesToTicks(77.5));
		}
		else if(autoSelection == 3){
			chassis.setDrivePIDSetpoint(chassis.convertInchesToTicks(85));
		}
		
		//Set up the driving PID
		chassis.resetDrivePID();
        chassis.enableDrivePID();
        
        //Set up the turning PID. For the lakeview comp., all the turning pid did was 
        //to make sure that the robot drove straight
        chassis.setTurnPIDSetpoint(chassis.getGyroAngle());
		chassis.resetTurnPID();
        chassis.enableTurnPID();

        //Make sure the gear arm is at "home"
		geararm.homeGear();
		System.out.println("Auto selection: " + autoSelection);
	}

	/**
	 * This function is called periodically during autonomous
	 */
	@Override
	public void autonomousPeriodic() {
		Scheduler.getInstance().run();
		
		//Variables to hold the output from the PID loops
		double targetDriveRPM = 0;
		double targetTurnRPM = 0;
		
		if(autoSelection == 2){
			//Steps in the autonomous sequence
			//Drop GearArm
			Robot.geararm.getGear();
			Robot.geararm.setGetGearToggle(true);
		//	System.out.println(Robot.geararm.getGetGearToggle());
			
			//1st Step: Drive to the airship
			if(stepInAuto == 0){
				//Get the output from the pid loop
				targetDriveRPM = chassis.getDrivePIDOutput();
				targetTurnRPM = chassis.getTurnPIDOutput();
				
				//Set the talon to those output
				//This is a equation found on chiefdelphi:
				//Left motor = driveOutput + turnOutput
				//Right motor = driveOutput - turnOutput
				//NOTE: if you just want to turn, just set targetDriveRPM to 0
				chassis.setLeftDriveSpeed((targetDriveRPM + targetTurnRPM) * Constants.kMaxDriveRPM);
				chassis.setRightDriveSpeed((targetDriveRPM - targetTurnRPM) * Constants.kMaxDriveRPM);
				
				//Check if the robot is past the distance setpoint
				if(chassis.convertTicksToInches(chassis.getDrivePIDInput()) >= (chassis.convertTicksToInches(chassis.getDrivePIDSetpoint()) - 3)){
					//When the robot drive pass its distance setpoint, start a 1s timer.
					if(getStartTimeInAuto){
						//Get the current time
						startTimeInAuto = timer.get();
						//Set this to false so that we don't repeatedly get the current time
						getStartTimeInAuto = false;	
					}
					
					//Once 1s pass when the robot reach its distance setpoint, go to the next step.
					//We wait 1s to let the robot "settle" into the setpoint with PID
					if(timer.get() - startTimeInAuto >= 1){
						//Reset variables for the next step to use
						startTimeInAuto = 0;
						getStartTimeInAuto = true;
						//Go to next step
						stepInAuto++;
					}
				}
			}
			//Drop gear
			else if(stepInAuto == 1){
				//Get the current time
				if(getStartTimeInAuto){
					startTimeInAuto = timer.get();
					getStartTimeInAuto = false;
				}
				//Wait for 1s before moving to the next step
				if(timer.get() - startTimeInAuto > 1){
					startTimeInAuto = 0;
					getStartTimeInAuto = true;
					stepInAuto++;
				}
			}
			//Slowly drive back from the airship.
			//At the time of the competition, I didn't test driving backward with the PID.
			//So to be safe, I set the talon to voltage control and just applied a negative
			//value. You would want to use PID for all driving in autonomous for the next
			//competitions
			else if(stepInAuto == 2){
				//Disable pid and enable voltage  control
				chassis.disableDrivePID();	
				chassis.resetTalonEncoders();
				chassis.setTalonsToVoltageControl();
				
				//Get the current time
				if(getStartTimeInAuto){
					startTimeInAuto = timer.get();
					getStartTimeInAuto = false;
				}
//				//Drive back for 2s
//				if(timer.get() - startTimeInAuto > 2){
//					chassis.drive(0, 0);
//					startTimeInAuto = 0;
//					getStartTimeInAuto = true;
//					stepInAuto++;
//				}
//				else{
//					chassis.drive(-.15, -.15);
//				}
			}
		}
		//Drive and pass the line
		else if(autoSelection == 3){
			targetDriveRPM = chassis.getDrivePIDOutput();
			targetTurnRPM = chassis.getTurnPIDOutput();

			chassis.setLeftDriveSpeed((targetDriveRPM + targetTurnRPM) * Constants.kMaxDriveRPM);
			chassis.setRightDriveSpeed((targetDriveRPM - targetTurnRPM) * Constants.kMaxDriveRPM);
		}
		
	}

	@Override
	public void teleopInit() {
		// This makes sure that the autonomous stops running when
		// teleop starts running. If you want the autonomous to
		// continue until interrupted by another command, remove
		// this line or comment it out.
		if (autonomousCommand != null)
			autonomousCommand.cancel();

		//Disable drive PID from the autonomous phase
		chassis.disableDrivePID();	
		chassis.resetTalonEncoders();
		chassis.setTalonsToVoltageControl();
		
		//turn on shooter
		//NOTE: I got a PID loop working for the shooter but I had problems turning it off and on
		//Look into this.
		//shooter.enableShooterPID();
		
		//Make sure robot is "home" before going into teleop
		climber.setToggle(false);
		roller.setIntakeToggle(false);
		roller.setReverseToggle(false);
		shooter.setToggle(false);
		chassis.setLowGear();
		chassis.compressorOn();
	}
	
	/**
	 * This function is called periodically during operator control
	 */
	@Override
	public void teleopPeriodic() {
		Scheduler.getInstance().run();
		while(isOperatorControl() && isEnabled()){
			//Check sensors, inputs, safety
			//Update buttons' current value
			//This is used for the edge trigger functions.
			//Remember "rising edge"
			oi.getButtonCurrentValues();
			oi.getTriggerCurrentValues();
			
			//Handle controller input
			//Button A
			if(oi.buttonA().edgeTrigger() || oi.coButtonA().edgeTrigger()){
				System.out.println("A");
				geararm.switchGetGearToggle();
				geararm.setDropGearToggle(false);
			}
			
			//CO DRIVER B
			if(oi.coButtonB().edgeTrigger()){
				geararm.setGetGearToggle(false);
			}

			//Button B
			if(oi.buttonB().edgeTrigger()){
				System.out.println("B");
//				geararm.switchDropGearToggle();
//				geararm.setGetGearToggle(false);
			}

			//Button X
			if(oi.buttonX().edgeTrigger() || oi.coButtonX().edgeTrigger()){
				System.out.println("X");
				shooter.switchReverseToggle();
			}

			//Button Y
			if(oi.getCoDriver(4) == true){
				System.out.println("Y");
				climber.climberOn();
				//climber.switchToggle();
			}
			else{
				climber.climberOff();
			}

			//Button LB
			if(oi.buttonLB().edgeTrigger() || oi.coButtonLB().edgeTrigger()){
				System.out.println("LB");
				//chassis.switchShiftToggle();
				roller.switchIntakeToggle();
				//Make sure reversing is off
				roller.setReverseToggle(false);
			}

			//Button RB - shooting
			if(oi.buttonRB().edgeTrigger()){
				System.out.println("RB");
				shooter.switchToggle();

				//If going to shoot, get the time that it is activing. this is used for the serializer timing
				if(shooter.getToggle() == true){
					startShootTime = timer.get();
				}
				
			}
			//Button START
			if(oi.buttonStart().edgeTrigger() || oi.coButtonStart().edgeTrigger()){
				System.out.println("Start");
				roller.switchReverseToggle();
				//Make sure intaking is off
				roller.setIntakeToggle(false);
			}

			//Left Trigger 
			if(oi.triggerLT().edgeTrigger() || oi.coTriggerLT().edgeTrigger()){
				System.out.println("LT");
				//chassis.setShiftToggle(false);
				chassis.setLowGear();
			}

			//Right Trigger
			if(oi.triggerRT().edgeTrigger() || oi.coTriggerRT().edgeTrigger()){
				System.out.println("RT");
				//chassis.setShiftToggle(true);
				chassis.setHighGear();
			}
			
			/*
			 * AFTER GETTING INPUT FROM THE DRIVERS, THEN APPLY THE OUTPUTS TO THE MOTORS
			 */
			
			//Handle the climber output
//			if(climber.getToggle()){
//				climber.climberOn();
//			}
//			else{
//				climber.climberOff();
//			}
			
			//Handle gear arm output
			if(geararm.getGetGearToggle()){
				geararm.inboundGear();
			}
			else if(geararm.getDropGearToggle()){
				geararm.dropGear();				
			}
			else{
				geararm.homeGear();
			}
			
			//Handle intake output
			if(roller.getIntakeToggle()){
				roller.intakeOn();
			}
			else if(roller.getReverseToggle()){
				roller.reverse();
			}
			else{
				roller.intakeOff();
			}
			
			//Handle shooter
			if(shooter.getToggle()){
				//startShootTime = timer.get(); //get the current time. Used in the shoot function
				shoot();
			}
			else{
				shooterOff();
			}
			if(shooter.getReverseToggle()){
				shooter.reverseShooter();
			}

//			//Handle drive output *OLD WAY (TANKDRIVE)*
//			chassis.driveWithJoysticks(oi.getLeftY(), oi.getRightY());

			//Handle drive output Arcade Drive
			chassis.driveWithJoysticksArcadeDrive(Robot.oi.getLeftY()*-1, Robot.oi.getRightX()*-1);
			//Loop ending
			//Update buttons' previous value
			oi.updateButtonPreviousValues();
			oi.updateTriggerPreviousValues();
		}
	}

	/**
	 * This function is called periodically during test mode
	 */
	@Override
	public void testPeriodic() {
		LiveWindow.run();
	}
	
	//boolean on = false;
	
	private void shoot(){
		Robot.shooter.shooterOn();
		//Start the serializer after 1s when the shooter is activated
	if(timer.get() - startShootTime >= 1){
		Robot.shooter.serializerOn();
		roller.conveyorOn();						
		}
	}
	
	private void shooterOff(){
		Robot.shooter.shooterOff();
		Robot.roller.conveyorOff();
		Robot.shooter.serializerOff();
	}
	
	private void dropGearAndMoveAway(){
		double angle = 0;
		chassis.setTalonsToVoltageControl();
		while(angle <= 0.2){
			//System.out.println(angle);
			Robot.geararm.setDesiredAngle(angle);
			angle+=0.0005;
		}
		
		Robot.geararm.setDropGearToggle(true);
		Robot.chassis.drive(0.0,0.0);
	}
	
}
